
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Header from "@/components/Header";

const ROICalculator = () => {
  const [metrics, setMetrics] = useState({
    monthlyEmailCapacity: 9000,
    customerLifetimeValue: 5000,
    replyRate: 3,
    positiveReplyRate: 30,
    meetingRate: 75,
    conversionRate: 15
  });

  const [calculatedMetrics, setCalculatedMetrics] = useState({
    monthlyProspects: 0,
    monthlyLeads: 0,
    monthlyMeetings: 0,
    monthlyDeals: 0,
    monthlyRevenue: 0
  });

  useEffect(() => {
    const monthlyProspects = Math.floor(metrics.monthlyEmailCapacity / 3);
    const monthlyLeads = (monthlyProspects * metrics.replyRate) / 100;
    const positiveMeetings = (monthlyLeads * metrics.positiveReplyRate) / 100;
    const monthlyMeetings = (positiveMeetings * metrics.meetingRate) / 100;
    const monthlyDeals = (monthlyMeetings * metrics.conversionRate) / 100;
    const monthlyRevenue = monthlyDeals * metrics.customerLifetimeValue;

    setCalculatedMetrics({
      monthlyProspects,
      monthlyLeads,
      monthlyMeetings,
      monthlyDeals,
      monthlyRevenue
    });
  }, [metrics]);

  const handleInputChange = (field: string, value: number) => {
    setMetrics(prev => ({ ...prev, [field]: value }));
  };

  const sdrCost = Math.ceil(calculatedMetrics.monthlyMeetings / 20) || 3;
  const annualSdrCost = sdrCost * 4000 * 12;
  const annualRevenue = calculatedMetrics.monthlyRevenue * 12;
  const payPerMeetingCost = calculatedMetrics.monthlyMeetings * 298;
  const annualPayPerMeetingCost = payPerMeetingCost * 12;

  return (
    <div className="min-h-screen bg-slate-900">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 text-white">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-4xl lg:text-6xl font-bold mb-6">
            What's Cheaper — Hiring SDRs<br />
            or <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">Paying Per Meeting?</span>
          </h1>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Use our calculator to discover how many deals you'll close and how much you'll save with our guaranteed meeting-based model.
          </p>
          <Button 
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-3 text-lg font-semibold rounded-full"
            onClick={() => document.getElementById('calculator')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Calculate Your ROI
          </Button>
        </div>
      </section>

      {/* Interactive ROI Calculator */}
      <section id="calculator" className="py-16 bg-slate-900">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-white text-center mb-12">Interactive ROI Calculator</h2>
          
          <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Your Business Metrics */}
            <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
              <h3 className="text-xl font-semibold text-white mb-6 flex items-center">
                <span className="w-3 h-3 bg-purple-500 rounded-full mr-3"></span>
                Your Business Metrics
              </h3>
              
              <div className="space-y-6">
                <div>
                  <Label className="text-gray-300 text-sm">Monthly Email Sending Capacity</Label>
                  <Input
                    type="number"
                    value={metrics.monthlyEmailCapacity}
                    onChange={(e) => handleInputChange('monthlyEmailCapacity', Number(e.target.value))}
                    className="bg-slate-700 border-slate-600 text-white mt-1"
                  />
                </div>
                
                <div>
                  <Label className="text-gray-300 text-sm">Customer Lifetime Value (USD)</Label>
                  <Input
                    type="number"
                    value={metrics.customerLifetimeValue}
                    onChange={(e) => handleInputChange('customerLifetimeValue', Number(e.target.value))}
                    className="bg-slate-700 border-slate-600 text-white mt-1"
                  />
                </div>
                
                <div>
                  <Label className="text-gray-300 text-sm">Reply Rate (%)</Label>
                  <Input
                    type="number"
                    value={metrics.replyRate}
                    onChange={(e) => handleInputChange('replyRate', Number(e.target.value))}
                    className="bg-slate-700 border-slate-600 text-white mt-1"
                  />
                </div>
                
                <div>
                  <Label className="text-gray-300 text-sm">Positive Reply Rate (%)</Label>
                  <Input
                    type="number"
                    value={metrics.positiveReplyRate}
                    onChange={(e) => handleInputChange('positiveReplyRate', Number(e.target.value))}
                    className="bg-slate-700 border-slate-600 text-white mt-1"
                  />
                </div>
                
                <div>
                  <Label className="text-gray-300 text-sm">Positive Replies → Meeting Rate (%)</Label>
                  <Input
                    type="number"
                    value={metrics.meetingRate}
                    onChange={(e) => handleInputChange('meetingRate', Number(e.target.value))}
                    className="bg-slate-700 border-slate-600 text-white mt-1"
                  />
                </div>
                
                <div>
                  <Label className="text-gray-300 text-sm">Meeting → Conversion Rate (%)</Label>
                  <Input
                    type="number"
                    value={metrics.conversionRate}
                    onChange={(e) => handleInputChange('conversionRate', Number(e.target.value))}
                    className="bg-slate-700 border-slate-600 text-white mt-1"
                  />
                </div>
                
                <div className="pt-4 border-t border-slate-600">
                  <Label className="text-gray-300 text-sm">Monthly Unique Prospects (Auto-calculated)</Label>
                  <div className="text-2xl font-bold text-white mt-1">
                    {calculatedMetrics.monthlyProspects.toLocaleString()}
                  </div>
                </div>
              </div>
            </div>

            {/* Performance Metrics */}
            <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
              <h3 className="text-xl font-semibold text-white mb-6 flex items-center">
                <span className="w-3 h-3 bg-blue-500 rounded-full mr-3"></span>
                Performance Metrics
              </h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-700 rounded-lg p-4 text-center">
                  <div className="text-sm text-blue-400 mb-1">Monthly Leads</div>
                  <div className="text-2xl font-bold text-white">{calculatedMetrics.monthlyLeads.toFixed(1)}</div>
                </div>
                
                <div className="bg-slate-700 rounded-lg p-4 text-center">
                  <div className="text-sm text-blue-400 mb-1">Monthly Meetings</div>
                  <div className="text-2xl font-bold text-white">{calculatedMetrics.monthlyMeetings.toFixed(1)}</div>
                </div>
                
                <div className="bg-slate-700 rounded-lg p-4 text-center">
                  <div className="text-sm text-blue-400 mb-1">Monthly Deals</div>
                  <div className="text-2xl font-bold text-white">{calculatedMetrics.monthlyDeals.toFixed(1)}</div>
                </div>
                
                <div className="bg-slate-700 rounded-lg p-4 text-center">
                  <div className="text-sm text-blue-400 mb-1">Monthly Revenue</div>
                  <div className="text-2xl font-bold text-white">${calculatedMetrics.monthlyRevenue.toLocaleString()}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Cost Comparison */}
      <section className="py-16 bg-slate-800">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-white text-center mb-12">Cost Comparison</h2>
          
          <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Traditional SDR Approach */}
            <div className="bg-slate-900 rounded-xl p-6 border border-red-500/30">
              <div className="flex items-center mb-4">
                <span className="text-2xl mr-3">🧑‍💼</span>
                <h3 className="text-xl font-semibold text-white">Traditional SDR Approach</h3>
              </div>
              
              <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 mb-6">
                <p className="text-red-400 text-sm">⚠️ Pay fixed monthly fees regardless of results</p>
              </div>
              
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-300">SDRs Needed</span>
                  <span className="text-white font-bold text-xl">{sdrCost}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-gray-300">Annual Cost</span>
                  <span className="text-white font-bold text-xl">${annualSdrCost.toLocaleString()}</span>
                </div>
                <p className="text-xs text-gray-400">{sdrCost} SDRs × $4k/month × 12 months</p>
                
                <div className="flex justify-between">
                  <span className="text-gray-300">Annual Revenue</span>
                  <span className="text-green-400 font-bold text-xl">${annualRevenue.toLocaleString()}</span>
                </div>
                
                <div className="flex justify-between pt-4 border-t border-slate-700">
                  <span className="text-gray-300">Annual ROI</span>
                  <span className="text-white font-bold text-xl">
                    {annualRevenue > 0 ? ((annualRevenue - annualSdrCost) / annualSdrCost * 100).toFixed(1) : 0}%
                  </span>
                </div>
              </div>
            </div>

            {/* Pay-Per-Meeting Model */}
            <div className="bg-slate-900 rounded-xl p-6 border border-green-500/30 relative">
              <div className="absolute -top-3 right-4 bg-green-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
                RECOMMENDED
              </div>
              
              <div className="flex items-center mb-4">
                <span className="text-2xl mr-3">✅</span>
                <h3 className="text-xl font-semibold text-white">Our Pay-Per-Meeting Model</h3>
              </div>
              
              <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4 mb-6">
                <p className="text-green-400 text-sm">✅ Pay only after meetings are booked - zero risk!</p>
              </div>
              
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-300">Monthly Meetings</span>
                  <span className="text-white font-bold text-xl">{calculatedMetrics.monthlyMeetings.toFixed(1)}</span>
                </div>
                <p className="text-xs text-gray-400">based on your metrics</p>
                
                <div className="flex justify-between">
                  <span className="text-gray-300">Total Cost</span>
                  <span className="text-white font-bold text-xl">${payPerMeetingCost.toLocaleString()}</span>
                </div>
                <p className="text-xs text-gray-400">{calculatedMetrics.monthlyMeetings.toFixed(1)} meetings × $298</p>
                
                <div className="flex justify-between">
                  <span className="text-gray-300">Expected Deals</span>
                  <span className="text-white font-bold text-xl">{calculatedMetrics.monthlyDeals.toFixed(1)}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-gray-300">Annual Revenue</span>
                  <span className="text-green-400 font-bold text-xl">${annualRevenue.toLocaleString()}</span>
                </div>
                
                <div className="flex justify-between pt-4 border-t border-slate-700">
                  <span className="text-gray-300">ROI</span>
                  <span className="text-green-400 font-bold text-xl">
                    {annualPayPerMeetingCost > 0 ? ((annualRevenue - annualPayPerMeetingCost) / annualPayPerMeetingCost * 100).toFixed(1) : 0}%
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Want to skip the hiring hassle and get guaranteed meetings instead?
          </h2>
          <Button 
            size="lg"
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-10 py-4 text-lg font-semibold rounded-full"
          >
            Book Free Strategy Call
          </Button>
        </div>
      </section>
    </div>
  );
};

export default ROICalculator;
