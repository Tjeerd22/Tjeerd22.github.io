
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import ResultsSection from "@/components/ResultsSection"; 
import ClientLogosSection from "@/components/ClientLogosSection";
import JourneySection from "@/components/JourneySection";
import ProblemSolutionSection from "@/components/ProblemSolutionSection";
import CaseStudiesSection from "@/components/CaseStudiesSection";
import NewComparisonSection from "@/components/NewComparisonSection";
import ProcessSection from "@/components/ProcessSection";
import SpecializationsSection from "@/components/SpecializationsSection";
import CallSchedulingForm from "@/components/CallSchedulingForm";
import FAQSection from "@/components/FAQSection";
import FooterCTA from "@/components/FooterCTA";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <HeroSection />
      <ResultsSection />
      <ClientLogosSection />
      <JourneySection />
      <ProblemSolutionSection />
      <div id="case-studies">
        <CaseStudiesSection />
      </div>
      <CallSchedulingForm />
      <NewComparisonSection />
      <ProcessSection />
      <SpecializationsSection />
      <FAQSection />
      <FooterCTA />
    </div>
  );
};

export default Index;
