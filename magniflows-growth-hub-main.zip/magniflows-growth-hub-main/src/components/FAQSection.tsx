
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQSection = () => {
  const faqs = [
    {
      question: "Wat kost een samenwerking met Magniflows?",
      answer: "Onze tarieven variëren tussen €2.500 - €5.000 per maand, afhankelijk van de scope en complexiteit van jouw project. We bieden altijd een gratis intakegesprek aan om een passend voorstel te maken. De investering verdient zichzelf meestal binnen 2-3 maanden terug door de gegenereerde pipeline."
    },
    {
      question: "Hoe snel kan ik resultaten verwachten?",
      answer: "De eerste gekwalificeerde leads komen meestal binnen 2-4 weken na de lancering. Volledige optimalisatie en schaling bereiken we binnen 8-12 weken. We monitoren alle KPI's wekelijks en delen transparante rapportages met concrete cijfers en verbeterpunten."
    },
    {
      question: "Bieden jullie garanties op resultaten?",
      answer: "Ja, we bieden een 90-dagen resultaatgarantie. Als we binnen deze periode niet minimaal 10 gekwalificeerde meetings hebben gegenereerd, krijg je je geld terug. Daarnaast bieden we 6 maanden gratis ondersteuning na projectoplevering."
    },
    {
      question: "Hoe werkt de onboarding en setup?",
      answer: "De onboarding duurt 2-4 weken en bestaat uit: (1) Grondige analyse van jouw ideale klantprofiel en markt, (2) Setup van alle systemen en integraties, (3) Creatie van gepersonaliseerde content en sequences, (4) Testing en optimalisatie voor de lancering. Je krijgt wekelijkse updates over de voortgang."
    },
    {
      question: "Welke industries en bedrijfsgroottes bedienen jullie?",
      answer: "We werken voornamelijk met B2B-bedrijven tussen 10-200 medewerkers in consultancy, technology, manufacturing en professionele dienstverlening. Het belangrijkste is dat je een duidelijk ideaal klantprofiel hebt en deal sizes van minimaal €10K per klant."
    },
    {
      question: "Wat gebeurt er als ik wil stoppen met de samenwerking?",
      answer: "Je kunt elk moment stoppen met een opzegtermijn van 30 dagen. Alle systemen, templates en data blijven van jou. We dragen alles over naar jouw team en bieden 30 dagen gratis ondersteuning tijdens de transitie om continuïteit te garanderen."
    },
    {
      question: "Hoe verhouden jullie je tot traditionele marketingbureaus?",
      answer: "Wij focussen 100% op sales-ready lead generation in plaats van brand awareness. Onze systemen zijn volledig geautomatiseerd en schaalbaar, terwijl traditionele bureaus vaak afhankelijk zijn van handmatig werk. Daarnaast bieden wij volledige transparantie en eigenaarschap van alle assets."
    },
    {
      question: "Welke technologieën en tools gebruiken jullie?",
      answer: "We gebruiken een geïntegreerde stack van leadgeneration tools, CRM-systemen, automation platforms en analytics. Alle tools worden geïntegreerd met jouw bestaande systemen. Je krijgt volledige toegang en eigenaarschap van alle accounts en data."
    }
  ];

  return (
    <section className="py-20 bg-magniflows-gray-light">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-magniflows-blue mb-6">
            Veelgestelde Vragen
          </h2>
          <p className="text-xl text-magniflows-gray max-w-3xl mx-auto">
            Alles wat je wilt weten over onze aanpak, tarieven en resultaten
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-white rounded-xl border-0 shadow-md hover:shadow-lg transition-shadow duration-300"
              >
                <AccordionTrigger className="text-left text-lg font-semibold text-magniflows-blue px-8 py-6 hover:no-underline hover:text-magniflows-orange transition-colors duration-300">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="px-8 pb-6 text-magniflows-gray leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
