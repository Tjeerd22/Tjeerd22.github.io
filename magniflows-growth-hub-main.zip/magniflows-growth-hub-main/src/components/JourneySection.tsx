
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const JourneySection = () => {
  const weeks = [
    {
      week: "Week 1",
      icon: "🛠️",
      title: "Leg de Basis",
      description: "We beginnen met onderzoek en zetten de juiste infrastructuur op."
    },
    {
      week: "Week 2", 
      icon: "🤖",
      title: "Bouw je Aanbod & Automatiseer",
      description: "Stel een duidelijk aanbod samen en zet slimme automatiseringen op."
    },
    {
      week: "Week 3",
      icon: "🚀", 
      title: "Lanceringstijd",
      description: "Campagnes gaan live. Laten we de bal aan het rollen krijgen."
    },
    {
      week: "Week 4",
      icon: "🤝",
      title: "Eerste Overwinningen", 
      description: "2-5 meetings beginnen binnen te komen. Vroege momentum."
    },
    {
      week: "Week 5",
      icon: "🔁",
      title: "Leren & Verbeteren",
      description: "Dubbel inzetten op wat werkt. Aanpassen wat niet werkt."
    },
    {
      week: "Week 6",
      icon: "📈",
      title: "Tijd om te Schalen", 
      description: "Het volume opdraaien. Meer bereik, meer leads."
    },
    {
      week: "Week 7",
      icon: "📅",
      title: "Meetings Stromen Binnen",
      description: "32 meetings geboekt. Je bent in volle beweging."
    },
    {
      week: "Week 8",
      icon: "🎉",
      title: "Mijlpaal Bereikt",
      description: "32 meetings geboekt. Je bent in volle beweging.",
      milestone: true
    }
  ];

  return (
    <section className="py-20 bg-white" id="services">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-magniflows-blue mb-6">
            Jouw 8-Weken Groeireis
          </h2>
          <p className="text-xl text-magniflows-gray max-w-3xl mx-auto">
            Van fundament tot schaal - zie precies hoe we jouw outbound systeem bouwen
          </p>
        </div>

        <Tabs defaultValue="Week 1" className="max-w-6xl mx-auto">
          <TabsList className="grid grid-cols-4 lg:grid-cols-8 w-full mb-12 bg-magniflows-blue/5">
            {weeks.map((week) => (
              <TabsTrigger 
                key={week.week} 
                value={week.week}
                className="data-[state=active]:bg-magniflows-blue data-[state=active]:text-white"
              >
                {week.week}
              </TabsTrigger>
            ))}
          </TabsList>

          {weeks.map((week) => (
            <TabsContent key={week.week} value={week.week} className="mt-8">
              <div className="bg-magniflows-blue/5 rounded-2xl p-12 text-center">
                <div className="text-6xl mb-6">{week.icon}</div>
                <h3 className="text-3xl font-bold text-magniflows-blue mb-4">{week.title}</h3>
                <p className="text-xl text-magniflows-gray max-w-2xl mx-auto leading-relaxed">
                  {week.description}
                </p>
                {week.milestone && (
                  <div className="mt-6 inline-block bg-magniflows-orange text-white px-6 py-3 rounded-full font-bold">
                    🎉 Mijlpaal Bereikt
                  </div>
                )}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  );
};

export default JourneySection;
