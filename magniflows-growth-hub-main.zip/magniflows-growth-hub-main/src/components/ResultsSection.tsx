
import { Card, CardContent } from "@/components/ui/card";

const ResultsSection = () => {
  const results = [
    {
      company: "TechConsult B.V.",
      industry: "IT Consultancy",
      result: "+ €450K aan pipeline",
      description: "In 6 maanden van 0 naar 15 gekwalificeerde leads per maand",
      metric: "300% groei in lead volume"
    },
    {
      company: "GrowthCoach",
      industry: "Business Coaching",
      result: "+ 180 nieuwe klanten",
      description: "Volledig geautomatiseerd acquisitiesysteem opgezet",
      metric: "45% conversieratio"
    },
    {
      company: "Scale Solutions",
      industry: "SaaS Platform",
      result: "+ €280K ARR",
      description: "Van manuele outreach naar schaalbaar groeisysteem",
      metric: "220% ROI in jaar 1"
    },
    {
      company: "InnovatePro",
      industry: "Manufacturing",
      result: "+ €650K deals",
      description: "Enterprise sales pipeline volledig geautomatiseerd",
      metric: "25% kortere sales cycle"
    },
    {
      company: "ConsultingPlus",
      industry: "Management Consulting",
      result: "+ 95 warme prospects",
      description: "Van cold calling naar inbound lead generation",
      metric: "40% hogere close rate"
    }
  ];

  return (
    <section className="py-20 bg-magniflows-gray-light">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-magniflows-blue mb-6">
            Concrete resultaten voor onze klanten
          </h2>
          <p className="text-xl text-magniflows-gray max-w-3xl mx-auto">
            Bekijk hoe bedrijven zoals de jouwe hun groei hebben versneld met onze bewezen aanpak
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {results.map((result, index) => (
            <Card key={index} className="hover:shadow-lg transition-all duration-300 hover:-translate-y-2 bg-white border-0 shadow-md">
              <CardContent className="p-8">
                <div className="space-y-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-magniflows-blue text-lg">{result.company}</h4>
                      <p className="text-magniflows-gray text-sm">{result.industry}</p>
                    </div>
                  </div>
                  
                  <div className="bg-magniflows-orange/10 rounded-lg p-4">
                    <div className="text-2xl font-bold text-magniflows-orange mb-2">
                      {result.result}
                    </div>
                    <div className="text-magniflows-blue font-semibold">
                      {result.metric}
                    </div>
                  </div>
                  
                  <p className="text-magniflows-gray leading-relaxed">
                    {result.description}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ResultsSection;
