
const ClientLogosSection = () => {
  const clients = [
    "TechConsult B.V.",
    "GrowthCoach",
    "Scale Solutions", 
    "InnovatePro",
    "ConsultingPlus",
    "BusinessFlow",
    "ProAdvice",
    "NextLevel B.V."
  ];

  return (
    <section className="py-16 bg-white border-y border-gray-100">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <p className="text-gray-600 text-lg font-medium">
            Trusted by 50+ companies in Netherlands and Belgium
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-6 items-center">
          {clients.map((client, index) => (
            <div 
              key={index} 
              className="flex items-center justify-center p-4 h-16 bg-gray-50 rounded-xl hover:shadow-md transition-all duration-300 border border-gray-100 hover:border-gray-200"
            >
              <div className="text-gray-600 font-semibold text-sm text-center">
                {client}
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <div className="inline-flex items-center space-x-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-full px-8 py-4 shadow-sm border border-gray-200">
            <span className="text-blue-600 font-semibold">⭐ 4.9/5 average score</span>
            <span className="text-gray-300">•</span>
            <span className="text-gray-600">50+ satisfied clients</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ClientLogosSection;
