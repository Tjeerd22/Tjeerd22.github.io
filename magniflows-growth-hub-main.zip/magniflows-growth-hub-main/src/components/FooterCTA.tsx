
import { Button } from "@/components/ui/button";
import { ArrowRight, Calendar, Mail, Phone, CheckCircle } from "lucide-react";

const FooterCTA = () => {
  return (
    <footer className="bg-magniflows-blue text-white">
      {/* Main CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl lg:text-6xl font-bold mb-8">
              Klaar om jouw groei te <span className="text-magniflows-orange">versnellen</span>?
            </h2>
            <p className="text-xl lg:text-2xl text-blue-100 mb-12 leading-relaxed">
              Plan een vrijblijvend intakegesprek van 20 minuten en ontdek hoe we jouw acquisitie kunnen automatiseren
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16">
              <Button 
                size="lg" 
                className="bg-magniflows-orange hover:bg-magniflows-orange/90 text-white px-10 py-6 text-xl font-bold transition-all duration-300 hover:scale-105 shadow-lg"
              >
                <Calendar className="mr-3 h-6 w-6" />
                Plan een intakegesprek
                <ArrowRight className="ml-3 h-6 w-6" />
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="border-2 border-white text-white hover:bg-white hover:text-magniflows-blue px-10 py-6 text-xl font-bold transition-all duration-300"
              >
                Download onze case study
              </Button>
            </div>

            <div className="grid md:grid-cols-3 gap-8 max-w-3xl mx-auto">
              <div className="text-center">
                <div className="bg-white/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Calendar className="h-8 w-8 text-magniflows-orange" />
                </div>
                <h4 className="font-bold text-lg mb-2">Gratis Intakegesprek</h4>
                <p className="text-blue-200">20 minuten, volledig vrijblijvend</p>
              </div>
              <div className="text-center">
                <div className="bg-white/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <ArrowRight className="h-8 w-8 text-magniflows-orange" />
                </div>
                <h4 className="font-bold text-lg mb-2">Snelle Setup</h4>
                <p className="text-blue-200">Live binnen 2-4 weken</p>
              </div>
              <div className="text-center">
                <div className="bg-white/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="h-8 w-8 text-magniflows-orange" />
                </div>
                <h4 className="font-bold text-lg mb-2">Gegarandeerde Resultaten</h4>
                <p className="text-blue-200">90 dagen geld-terug-garantie</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer Info */}
      <div className="border-t border-white/20 py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Company Info */}
            <div className="space-y-4">
              <h3 className="text-2xl font-bold text-magniflows-orange">Magniflows</h3>
              <p className="text-blue-200 leading-relaxed">
                Wij bouwen hands-off groeisystemen voor ambitieuze B2B-bedrijven die hun acquisitie willen automatiseren.
              </p>
            </div>

            {/* Contact */}
            <div className="space-y-4">
              <h4 className="font-bold text-lg">Contact</h4>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Mail className="h-5 w-5 text-magniflows-orange" />
                  <span className="text-blue-200">hello@magniflows.nl</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-magniflows-orange" />
                  <span className="text-blue-200">+31 (0)20 123 4567</span>
                </div>
              </div>
            </div>

            {/* Services */}
            <div className="space-y-4">
              <h4 className="font-bold text-lg">Services</h4>
              <ul className="space-y-2 text-blue-200">
                <li>Lead Generation Automatisering</li>
                <li>Sales Funnel Optimalisatie</li>
                <li>CRM Integratie & Setup</li>
                <li>Performance Monitoring</li>
              </ul>
            </div>

            {/* Industries */}
            <div className="space-y-4">
              <h4 className="font-bold text-lg">Industries</h4>
              <ul className="space-y-2 text-blue-200">
                <li>IT Consultancy</li>
                <li>Business Coaching</li>
                <li>SaaS Platforms</li>
                <li>Manufacturing</li>
                <li>Professional Services</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-white/20 mt-12 pt-8 text-center text-blue-200">
            <p>&copy; 2024 Magniflows. Alle rechten voorbehouden.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default FooterCTA;
