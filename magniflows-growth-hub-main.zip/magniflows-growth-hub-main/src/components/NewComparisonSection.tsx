
const NewComparisonSection = () => {
  const options = [
    {
      name: "Magniflows",
      timeToResults: "21-30 Dagen",
      failureRate: "Onwaarschijnlijk",
      price: "Gebaseerd Op Resultaten",
      guarantees: "Ja",
      highlight: true
    },
    {
      name: "Een SDR Inhuren",
      timeToResults: "3 Maanden", 
      failureRate: "Gemiddeld",
      price: "+€8,000/maand",
      guarantees: "Zelden"
    },
    {
      name: "Marketing Bureau",
      timeToResults: "2-4 Weken",
      failureRate: "Hoog", 
      price: "+€5K+ Media Budget",
      guarantees: "Zelden"
    },
    {
      name: "Doe Het Zelf",
      timeToResults: "3-6 Maanden",
      failureRate: "Zeer Hoog",
      price: "€3K Voor Software + Verspilde Tijd", 
      guarantees: "Zelden"
    }
  ];

  const criteria = [
    "Tijd tot resultaten",
    "Faalpercentage", 
    "Prijs",
    "Garanties"
  ];

  return (
    <section className="py-20 bg-magniflows-gray-light">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-magniflows-blue mb-6">
            Laten we je opties vergelijken
          </h2>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-4 gap-8">
            {options.map((option, index) => (
              <div 
                key={index}
                className={`rounded-2xl p-8 ${
                  option.highlight 
                    ? 'bg-magniflows-blue text-white shadow-2xl scale-105' 
                    : 'bg-white shadow-lg'
                }`}
              >
                <h3 className={`text-2xl font-bold mb-8 text-center ${
                  option.highlight ? 'text-white' : 'text-magniflows-blue'
                }`}>
                  {option.name}
                </h3>
                
                <div className="space-y-6">
                  <div>
                    <div className={`font-semibold mb-2 ${
                      option.highlight ? 'text-blue-200' : 'text-magniflows-gray'
                    }`}>
                      Tijd tot resultaten
                    </div>
                    <div className="font-bold">{option.timeToResults}</div>
                  </div>
                  
                  <div>
                    <div className={`font-semibold mb-2 ${
                      option.highlight ? 'text-blue-200' : 'text-magniflows-gray'
                    }`}>
                      Faalpercentage
                    </div>
                    <div className="font-bold">{option.failureRate}</div>
                  </div>
                  
                  <div>
                    <div className={`font-semibold mb-2 ${
                      option.highlight ? 'text-blue-200' : 'text-magniflows-gray'
                    }`}>
                      Prijs
                    </div>
                    <div className="font-bold">{option.price}</div>
                  </div>
                  
                  <div>
                    <div className={`font-semibold mb-2 ${
                      option.highlight ? 'text-blue-200' : 'text-magniflows-gray'
                    }`}>
                      Garanties
                    </div>
                    <div className="font-bold">{option.guarantees}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default NewComparisonSection;
