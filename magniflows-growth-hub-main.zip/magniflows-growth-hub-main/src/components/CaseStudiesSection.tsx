
import { Card, CardContent } from "@/components/ui/card";
import { ArrowUp, Calendar, Target, TrendingUp } from "lucide-react";

const CaseStudiesSection = () => {
  const caseStudies = [
    {
      company: "TechConsult B.V.",
      industry: "IT Consultancy",
      challenge: "Manuele outreach leverde slechts 2-3 meetings per maand op. Het verkoopteam had geen tijd meer voor daadwerkelijk verkopen.",
      solution: "Volledige automatisering van lead generation met gepersonaliseerde sequences en multi-channel approach.",
      results: {
        meetings: "Van 3 naar 15 meetings/maand",
        pipeline: "€450K nieuwe pipeline",
        roi: "320% ROI",
        timeframe: "6 maanden"
      },
      quote: "Eindelijk kunnen we ons focussen op verkopen in plaats van prospecting. Het systeem draait volledig automatisch.",
      person: "Mark Janssen, Sales Director"
    },
    {
      company: "Scale Solutions",
      industry: "SaaS Platform", 
      challenge: "Inconsistente lead kwaliteit en hoge customer acquisition costs. Moeite met het identificeren van de juiste prospects.",
      solution: "Data-gedreven targeting en geautomatiseerde kwalificatie met AI-powered lead scoring.",
      results: {
        meetings: "Van 5 naar 22 meetings/maand", 
        pipeline: "€280K ARR toegevoegd",
        roi: "220% ROI",
        timeframe: "4 maanden"
      },
      quote: "De kwaliteit van onze leads is dramatisch verbeterd. We praten nu alleen nog met prospects die echt interesse hebben.",
      person: "Sarah van der Berg, CEO"
    }
  ];

  return (
    <section className="py-20 bg-magniflows-gray-light">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-magniflows-blue mb-6">
            Case Studies: Van Uitdaging naar Succes
          </h2>
          <p className="text-xl text-magniflows-gray max-w-3xl mx-auto">
            Ontdek hoe we concrete problemen hebben opgelost met meetbare resultaten
          </p>
        </div>

        <div className="space-y-12">
          {caseStudies.map((study, index) => (
            <Card key={index} className="bg-white border-0 shadow-lg hover:shadow-xl transition-all duration-300">
              <CardContent className="p-8 lg:p-12">
                <div className="grid lg:grid-cols-3 gap-8">
                  {/* Company Info */}
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-2xl font-bold text-magniflows-blue">{study.company}</h3>
                      <p className="text-magniflows-orange font-semibold">{study.industry}</p>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-bold text-magniflows-blue mb-2">Uitdaging</h4>
                        <p className="text-magniflows-gray text-sm leading-relaxed">{study.challenge}</p>
                      </div>
                      
                      <div>
                        <h4 className="font-bold text-magniflows-blue mb-2">Oplossing</h4>
                        <p className="text-magniflows-gray text-sm leading-relaxed">{study.solution}</p>
                      </div>
                    </div>
                  </div>

                  {/* Results */}
                  <div className="lg:col-span-2">
                    <h4 className="font-bold text-magniflows-blue mb-6 text-xl">Resultaten na {study.results.timeframe}</h4>
                    
                    <div className="grid sm:grid-cols-2 gap-6 mb-8">
                      <div className="bg-magniflows-blue/5 rounded-xl p-6">
                        <div className="flex items-center mb-3">
                          <Calendar className="h-6 w-6 text-magniflows-orange mr-3" />
                          <span className="font-semibold text-magniflows-blue">Meetings</span>
                        </div>
                        <div className="text-2xl font-bold text-magniflows-blue">{study.results.meetings}</div>
                      </div>
                      
                      <div className="bg-magniflows-orange/5 rounded-xl p-6">
                        <div className="flex items-center mb-3">
                          <Target className="h-6 w-6 text-magniflows-orange mr-3" />
                          <span className="font-semibold text-magniflows-blue">Pipeline</span>
                        </div>
                        <div className="text-2xl font-bold text-magniflows-orange">{study.results.pipeline}</div>
                      </div>
                      
                      <div className="bg-green-50 rounded-xl p-6">
                        <div className="flex items-center mb-3">
                          <TrendingUp className="h-6 w-6 text-green-600 mr-3" />
                          <span className="font-semibold text-magniflows-blue">ROI</span>
                        </div>
                        <div className="text-2xl font-bold text-green-600">{study.results.roi}</div>
                      </div>
                      
                      <div className="bg-blue-50 rounded-xl p-6">
                        <div className="flex items-center mb-3">
                          <ArrowUp className="h-6 w-6 text-blue-600 mr-3" />
                          <span className="font-semibold text-magniflows-blue">Tijdframe</span>
                        </div>
                        <div className="text-2xl font-bold text-blue-600">{study.results.timeframe}</div>
                      </div>
                    </div>

                    <div className="bg-magniflows-blue/5 rounded-xl p-6 border-l-4 border-magniflows-orange">
                      <p className="text-magniflows-blue italic text-lg leading-relaxed mb-3">"{study.quote}"</p>
                      <p className="text-magniflows-gray font-semibold">— {study.person}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CaseStudiesSection;
