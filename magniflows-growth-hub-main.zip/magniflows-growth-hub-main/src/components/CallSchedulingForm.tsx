import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

const CallSchedulingForm = () => {
  const { register, handleSubmit, reset } = useForm();

  const onSubmit = (data: any) => {
    console.log(data);
    reset();
  };

  const benefits = [
    "Custom Strategy",
    "Expert Call",
    "Action Plan",
    "100% Free Consultation"
  ];

  return (
    <section className="py-20 bg-magniflows-gray-light">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12 items-start">
          <form
            onSubmit={handleSubmit(onSubmit)}
            className="bg-white rounded-2xl p-8 shadow-lg space-y-6"
          >
            <h2 className="text-3xl font-bold text-magniflows-blue mb-4">
              Plan een Strategiegesprek
            </h2>
            <div className="grid gap-4">
              <input
                type="text"
                placeholder="Naam"
                {...register('name')}
                className="border border-gray-300 rounded-md p-3"
                required
              />
              <input
                type="email"
                placeholder="E-mail"
                {...register('email')}
                className="border border-gray-300 rounded-md p-3"
                required
              />
              <input
                type="text"
                placeholder="Branche"
                {...register('branch')}
                className="border border-gray-300 rounded-md p-3"
              />
              <input
                type="text"
                placeholder="Omzet"
                {...register('revenue')}
                className="border border-gray-300 rounded-md p-3"
              />
              <textarea
                placeholder="Grootste uitdaging"
                {...register('challenge')}
                className="border border-gray-300 rounded-md p-3"
                rows={4}
              />
            </div>
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-magniflows-blue to-magniflows-purple hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-3 rounded-md"
            >
              Plan Gesprek
            </Button>
          </form>
          <div className="space-y-6">
            <h3 className="text-3xl font-bold text-magniflows-blue">
              Waarom plannen?
            </h3>
            <ul className="space-y-4">
              {benefits.map((benefit) => (
                <li key={benefit} className="flex items-start space-x-3">
                  <Check className="text-magniflows-orange flex-shrink-0" />
                  <span className="text-magniflows-blue font-medium">{benefit}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallSchedulingForm;
