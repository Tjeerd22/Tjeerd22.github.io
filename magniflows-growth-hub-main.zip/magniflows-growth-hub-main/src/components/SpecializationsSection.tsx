
const SpecializationsSection = () => {
  const specializations = [
    {
      title: "IT Support (Zorgverlening)",
      description: "Gespecialiseerde outreach voor zorgverlening IT-providers"
    },
    {
      title: "Cybersecurity", 
      description: "Genereer gekwalificeerde leads voor beveiligingsoplossingen"
    },
    {
      title: "B2B SaaS",
      description: "Schaal je softwarebedrijf met gerichte outreach"
    },
    {
      title: "Recruitment",
      description: "Schaal je talent acquisitie bedrijf"
    }
  ];

  return (
    <section className="py-20 bg-magniflows-gray-light">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-magniflows-blue mb-6">
            Gespecialiseerde Expertise in Jouw Industrie
          </h2>
          <p className="text-xl text-magniflows-gray max-w-3xl mx-auto">
            We focussen op specifieke B2B niches om maximale resultaten te leveren
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
          {specializations.map((spec, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <h3 className="text-xl font-bold text-magniflows-blue mb-4">{spec.title}</h3>
              <p className="text-magniflows-gray leading-relaxed">{spec.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SpecializationsSection;
