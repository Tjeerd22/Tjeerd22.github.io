
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, XCircle, AlertCircle } from "lucide-react";

const ComparisonSection = () => {
  const comparisonData = [
    {
      feature: "Setup tijd",
      magniflows: { value: "2-4 weken", icon: CheckCircle, color: "text-green-600" },
      inhouse: { value: "6-12 maanden", icon: AlertCircle, color: "text-yellow-600" },
      agencies: { value: "8-16 weken", icon: AlertCircle, color: "text-yellow-600" },
      diy: { value: "3-6 maanden", icon: XCircle, color: "text-red-600" }
    },
    {
      feature: "Maandelijkse kosten",
      magniflows: { value: "€2.500 - €5.000", icon: CheckCircle, color: "text-green-600" },
      inhouse: { value: "€8.000 - €15.000", icon: XCircle, color: "text-red-600" },
      agencies: { value: "€3.000 - €8.000", icon: AlertCircle, color: "text-yellow-600" },
      diy: { value: "€500 - €2.000", icon: AlertCircle, color: "text-yellow-600" }
    },
    {
      feature: "Expertise vereist",
      magniflows: { value: "Geen", icon: CheckCircle, color: "text-green-600" },
      inhouse: { value: "Hoog", icon: XCircle, color: "text-red-600" },
      agencies: { value: "Beperkt", icon: AlertCircle, color: "text-yellow-600" },
      diy: { value: "Zeer hoog", icon: XCircle, color: "text-red-600" }
    },
    {
      feature: "Controle & transparantie",
      magniflows: { value: "Volledig", icon: CheckCircle, color: "text-green-600" },
      inhouse: { value: "Volledig", icon: CheckCircle, color: "text-green-600" },
      agencies: { value: "Beperkt", icon: AlertCircle, color: "text-yellow-600" },
      diy: { value: "Volledig", icon: CheckCircle, color: "text-green-600" }
    },
    {
      feature: "Resultaat garantie",
      magniflows: { value: "Ja, 90 dagen", icon: CheckCircle, color: "text-green-600" },
      inhouse: { value: "Nee", icon: XCircle, color: "text-red-600" },
      agencies: { value: "Beperkt", icon: AlertCircle, color: "text-yellow-600" },
      diy: { value: "Nee", icon: XCircle, color: "text-red-600" }
    },
    {
      feature: "Schaalbaarheid",
      magniflows: { value: "Automatisch", icon: CheckCircle, color: "text-green-600" },
      inhouse: { value: "Handmatig", icon: AlertCircle, color: "text-yellow-600" },
      agencies: { value: "Beperkt", icon: AlertCircle, color: "text-yellow-600" },
      diy: { value: "Moeilijk", icon: XCircle, color: "text-red-600" }
    }
  ];

  const approaches = [
    { name: "Magniflows", highlight: true },
    { name: "In-house team", highlight: false },
    { name: "Traditionele agencies", highlight: false },
    { name: "DIY aanpak", highlight: false }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-magniflows-blue mb-6">
            Waarom kiezen voor Magniflows?
          </h2>
          <p className="text-xl text-magniflows-gray max-w-3xl mx-auto">
            Vergelijk onze aanpak met andere opties en zie waarom we de beste keuze zijn
          </p>
        </div>

        <Card className="shadow-xl border-0 overflow-hidden">
          <CardHeader className="bg-magniflows-blue text-white p-6">
            <CardTitle className="text-2xl text-center">Vergelijkingstabel</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-magniflows-gray-light">
                    <th className="text-left p-4 font-bold text-magniflows-blue">Feature</th>
                    {approaches.map((approach, index) => (
                      <th 
                        key={index} 
                        className={`text-center p-4 font-bold ${
                          approach.highlight 
                            ? 'bg-magniflows-orange text-white' 
                            : 'text-magniflows-blue'
                        }`}
                      >
                        {approach.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {comparisonData.map((row, rowIndex) => (
                    <tr key={rowIndex} className={rowIndex % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                      <td className="p-4 font-semibold text-magniflows-blue border-r border-gray-200">
                        {row.feature}
                      </td>
                      <td className="p-4 text-center bg-magniflows-orange/5 border-r border-magniflows-orange/20">
                        <div className="flex items-center justify-center space-x-2">
                          <row.magniflows.icon className={`h-5 w-5 ${row.magniflows.color}`} />
                          <span className="font-semibold text-magniflows-blue">{row.magniflows.value}</span>
                        </div>
                      </td>
                      <td className="p-4 text-center border-r border-gray-200">
                        <div className="flex items-center justify-center space-x-2">
                          <row.inhouse.icon className={`h-5 w-5 ${row.inhouse.color}`} />
                          <span className="text-magniflows-gray">{row.inhouse.value}</span>
                        </div>
                      </td>
                      <td className="p-4 text-center border-r border-gray-200">
                        <div className="flex items-center justify-center space-x-2">
                          <row.agencies.icon className={`h-5 w-5 ${row.agencies.color}`} />
                          <span className="text-magniflows-gray">{row.agencies.value}</span>
                        </div>
                      </td>
                      <td className="p-4 text-center">
                        <div className="flex items-center justify-center space-x-2">
                          <row.diy.icon className={`h-5 w-5 ${row.diy.color}`} />
                          <span className="text-magniflows-gray">{row.diy.value}</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default ComparisonSection;
