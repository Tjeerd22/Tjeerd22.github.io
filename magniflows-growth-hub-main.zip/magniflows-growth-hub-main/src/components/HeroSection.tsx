
import { Button } from "@/components/ui/button";
import { ArrowRight, Play } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 text-white overflow-hidden">
      {/* Background overlay */}
      <div className="absolute inset-0 bg-black/20"></div>
      
      <div className="relative container mx-auto px-6 pt-24 pb-16">
        <div className="max-w-6xl mx-auto">
          {/* Top badge */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center px-6 py-3 bg-white/10 backdrop-blur-sm rounded-full border border-white/20">
              <span className="text-white font-medium">Automatiseer Lead Acquisitie en Schaal je Outbound</span>
            </div>
          </div>

          {/* Main heading */}
          <div className="text-center mb-16">
            <h1 className="text-5xl lg:text-7xl font-bold leading-tight mb-8">
              Wij bouwen{" "}
              <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-blue-500 bg-clip-text text-transparent">
                hands-off groeisystemen
              </span>
              <br />
              voor B2B-leiders
            </h1>
            
            <p className="text-xl lg:text-2xl text-gray-300 leading-relaxed max-w-4xl mx-auto mb-12">
              We hebben onze klanten geholpen om meer dan{" "}
              <span className="text-blue-400 font-semibold">€7M+</span> aan potentiële deals te ontgrendelen, 
              hen bevrijd van de gedoe van referrals, dure SDR's, amateuristische bureaus en zorgen 
              over de dalende economie.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-10 py-4 text-lg font-semibold transition-all duration-300 hover:scale-105 shadow-lg rounded-full"
              >
                Gratis Strategiegesprek
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="border-2 border-white/30 text-white hover:bg-white/10 px-10 py-4 text-lg font-semibold transition-all duration-300 rounded-full bg-transparent"
              >
                <Play className="mr-2 h-5 w-5" />
                Bekijk Case Studies
              </Button>
            </div>
          </div>

          {/* Results section */}
          <div className="text-center mb-16">
            <h2 className="text-2xl font-semibold text-gray-300 mb-12">We genereerden voor onze klanten:</h2>
            
            <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
                <div className="text-4xl lg:text-5xl font-bold text-green-400 mb-2">+€3M</div>
                <div className="text-gray-300 font-medium">Omzet gegenereerd</div>
              </div>
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
                <div className="text-4xl lg:text-5xl font-bold text-blue-400 mb-2">+2,500</div>
                <div className="text-gray-300 font-medium">Sales meetings</div>
              </div>
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
                <div className="text-4xl lg:text-5xl font-bold text-purple-400 mb-2">+€7M</div>
                <div className="text-gray-300 font-medium">Sales pipeline</div>
              </div>
            </div>
          </div>

          {/* New section - The new way to scale */}
          <div className="text-center mb-16 bg-white/5 rounded-3xl p-12 border border-white/10">
            <h2 className="text-3xl font-bold mb-8 text-white">De nieuwe manier om te schalen.</h2>
            <div className="max-w-4xl mx-auto text-lg text-gray-300 leading-relaxed space-y-4">
              <p>
                Cold email heeft een frustrerende afweging: of je offert kwaliteit op voor volume (spray and pray), 
                of je besteedt veel te veel geld aan mensen die de hele dag zitten om één of twee geweldige emails te schrijven. 
                Onze aanpak is anders.
              </p>
              <p>
                Elke email die we versturen is tijdig en relevant, en we kunnen dit op oneindige schaal doen. 
                We winnen je miljoenen in pipeline.
              </p>
              <p>
                Het schalen van gepersonaliseerde cold outbound is ook makkelijk verkeerd te doen—wat gevolgen heeft 
                voor zowel je merk (je er slecht uit laten zien) als je bedrijf (geld verliezen). 
                Wanneer je met ons werkt, ben je in goede handen.
              </p>
              <p className="font-semibold text-blue-400">
                We hebben miljoenen emails verstuurd, bijna €10M in pipeline gegenereerd, en zijn neurotisch 
                geobsedeerd met het goed krijgen van de kleine details zodat alles soepel verloopt.
              </p>
            </div>
            
            <div className="mt-8 flex items-center justify-center space-x-4">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-xl">M</span>
              </div>
              <div className="text-left">
                <div className="font-bold text-white">Mark Janssen</div>
                <div className="text-gray-400">Mark Janssen, Oprichter en Reiziger</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
