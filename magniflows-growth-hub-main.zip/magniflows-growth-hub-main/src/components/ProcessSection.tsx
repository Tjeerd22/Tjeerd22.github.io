
import { CheckCircle } from "lucide-react";

const ProcessSection = () => {
  const steps = [
    {
      step: "01",
      title: "Bouw Systeem",
      description: "We creëren jouw op maat gemaakte outbound infrastructuur met bewezen templates en sequences"
    },
    {
      step: "02",
      title: "Target Besluitvormers", 
      description: "Ons team identificeert en benadert jouw ideale prospects met gepersonaliseerde berichten"
    },
    {
      step: "03",
      title: "Lever Resultaten",
      description: "Krijg consistente meetings en pipelinegroei met onze bewezen systematische aanpak"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-magniflows-blue mb-6">
            Ons Bewezen 3-Stappen Proces
          </h2>
          <p className="text-xl text-magniflows-gray max-w-3xl mx-auto">
            Van systeemopzet tot consistente resultaten in slechts 60 dagen
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-12 max-w-6xl mx-auto">
          {steps.map((step, index) => (
            <div key={index} className="text-center">
              <div className="bg-magniflows-blue text-white text-3xl font-bold w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-8">
                {step.step}
              </div>
              <h3 className="text-2xl font-bold text-magniflows-blue mb-6">{step.title}</h3>
              <p className="text-magniflows-gray text-lg leading-relaxed">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;
