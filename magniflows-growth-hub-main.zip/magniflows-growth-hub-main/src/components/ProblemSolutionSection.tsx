
import { CheckCircle, XCircle, ArrowRight } from "lucide-react";

const ProblemSolutionSection = () => {
  const problems = [
    "Je verkoopteam besteedt 70% van hun tijd aan prospecting in plaats van verkopen",
    "Cold calling en LinkedIn outreach leveren steeds minder resultaat op",
    "Je mist kwalificeerde leads omdat je acquisitieproces niet schaalbaar is",
    "Inconsistente resultaten door afhankelijkheid van individuele verkopers"
  ];

  const methodSteps = [
    {
      step: "01",
      title: "Analyse & Strategie",
      description: "We analyseren jouw ideale klantprofiel en ontwikkelen een data-gedreven acquisitie strategie die aansluit bij jouw markt."
    },
    {
      step: "02", 
      title: "Systeem & Automatisering",
      description: "We bouwen een volledig geautomatiseerd groeisysteem met proven templates, sequences en tracking die 24/7 draaien."
    },
    {
      step: "03",
      title: "Optimalisatie & Schaling",
      description: "Continue optimalisatie op basis van data en resultaten. Van een handvol leads naar een voorspelbare stroom prospects."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-6">
        {/* Problem Section */}
        <div className="mb-20">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-magniflows-blue mb-6">
              Herkenbaar? Deze uitdagingen houden je groei tegen
            </h2>
            <p className="text-xl text-magniflows-gray max-w-3xl mx-auto">
              De meeste B2B-bedrijven worstelen met dezelfde acquisitie problemen
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {problems.map((problem, index) => (
              <div key={index} className="flex items-start space-x-4 p-6 bg-red-50 rounded-xl border border-red-100">
                <XCircle className="h-6 w-6 text-red-500 flex-shrink-0 mt-1" />
                <p className="text-magniflows-blue font-medium leading-relaxed">{problem}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Solution Section */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center p-4 bg-magniflows-orange/10 rounded-full mb-8">
            <ArrowRight className="h-8 w-8 text-magniflows-orange" />
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-magniflows-blue mb-6">
            De Magniflows Methode
          </h2>
          <p className="text-xl text-magniflows-gray max-w-3xl mx-auto">
            Onze bewezen 3-stappen aanpak transformeert jouw acquisitie van tijdrovend naar volledig geautomatiseerd
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {methodSteps.map((step, index) => (
            <div key={index} className="relative">
              <div className="bg-magniflows-blue/5 rounded-2xl p-8 h-full hover:bg-magniflows-blue/10 transition-colors duration-300">
                <div className="flex items-center mb-6">
                  <div className="bg-magniflows-orange text-white text-xl font-bold w-12 h-12 rounded-full flex items-center justify-center">
                    {step.step}
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-magniflows-blue mb-4">{step.title}</h3>
                <p className="text-magniflows-gray leading-relaxed">{step.description}</p>
              </div>
              
              {index < methodSteps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                  <ArrowRight className="h-6 w-6 text-magniflows-orange" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProblemSolutionSection;
